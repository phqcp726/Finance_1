i=0.001;g=0.017;
G0=108;
T0=71;
D0=1458;
Y0=545;
S0=G0-T0;
d0=D0/Y0;
s0=S0/Y0;

N=400;
t=[1:1:N];
for n=1:N
 p=1/(1+g)^n;
 if (n==1)
   Y(n)=Y0;
   D(n)=D0;
   d(n)=D(n)/Y(n);
 else
   Y(n)=Y(n-1)*(1+g);
   D(n)=D(n-1)*(1+i)+S0;
   d(n)=D(n)/Y(n);
 endif
endfor

subplot(221);
 plot(t,Y);grid('on');
 xlabel('Time[year]');ylabel('GDP[TyoYen]');
 title('[1] Growth of GDP');
subplot(222);
 plot(t,D);grid('on');
 xlabel('Time[year]');ylabel('Deficit[TyoYen]');
 title('[2] Transition of Deficit');
subplot(223);
 plot(t,d);grid('on');
 xlabel('Time[year]');ylabel('Deficit/GDP[rate]');
 title('[3] Transition of Deficit/GDP');

setumei("[Case-2a]  G-T=const>0",224);

printf("year Y        D     d\n");
for k=[1 100 150 N]
 printf("%3d: %6d %7d %2f \n",k,int32(Y(k)),int32(D(k)),d(k));
endfor

