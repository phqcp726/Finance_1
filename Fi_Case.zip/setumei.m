function setumei(txh,pos)
 subplot(pos);
 tx0="Financial Sustainability ";
 tx1="[1] Growth of GDP";
 tx2="[2] Deficit increase";
 tx3="[3] Deficit/GDP";
 text(0.05,0.90,txh,"fontsize",14);
 text(0.1,0.7,tx0,"fontsize",14);
 text(0.2,0.50,tx1,"fontsize",14);
 text(0.2,0.35,tx2,"fontsize",14);
 text(0.2,0.20,tx3,"fontsize",14);
endfunction

